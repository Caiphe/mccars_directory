<?php 
  //- Scanning the license and the ID book
 // - Code (Invoice Number and cellphone Number) to allow to user to access the system
 //- Login Details and Cell Number AND ID Number
 //-Only Used cars
 //- Customers Won't pay from my website
 //- My website has to communicate with Gate Book Database
//- 
?>