<?php
  session_start();
  include('includes/db.php');
  include('includes/header.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
</head>
<body>		
	</div>
	<div class="w3-container w3-center myMainCont">
		<br><br><br><br><br><br><br><br><br>
 </div>

</body>
<?php include('includes/footer.php') ?>
</html>