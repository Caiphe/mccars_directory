<?php
 session_start();
 include('header.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<section>
		
	</section>

</body>
<?php include('script.php') ?>
</html>