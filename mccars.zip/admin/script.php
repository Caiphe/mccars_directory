 
 
  <!-- bootstrap 
 <script src="js/jquery-1.8.3.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
  -->
 
  <!-- charts scripts -->
 
 
  <!-- jQuery full calendar 
 <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
  <script src="js/owl.carousel.js"></script>
   <script src="js/fullcalendar.min.js"></script>
    <script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
     <script src="assets/jquery-knob/js/jquery.knob.js"></script>
  <script src="js/jquery.sparkline.js" type="text/javascript"></script>
  -->
 
    <!-- Full Google Calendar - Calendar -->
   
    <!--script for this page only-->
    <!-- custom select 
    <script src="js/jquery.customSelect.min.js"></script>
    <script src="assets/chart-master/Chart.js"></script>

    <!--custome script for all page-->
  
    <!-- custom script for this page-->
