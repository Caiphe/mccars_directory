<?php
  $db = new PDO('mysql:host=127.0.0.1;dbname=mccarsdata', 'root', 'root');
  //include('flav.php');
  //$connect = mysqli_connect("127.0.0.1", "root" , "root", "mccarsdata");
?>