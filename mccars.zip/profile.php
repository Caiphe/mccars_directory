<?php
  session_start();
  include('includes/db.php');
  include('includes/header.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
</head>
<body>		
<div class="container-fluid" id="after_menu_gradiant">	
	</div>
	<div class="w3-container w3-center myMainCont">
		<br><br><br><br><br>
           <h2>PROFILE PAGE COMING SOON</h2>
		<br><br><br><br>
 </div>

</body>
<?php include('includes/footer.php') ?>
</html>