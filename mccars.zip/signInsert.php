<?php 
   include('includes/db.php');
   
?>